import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footertab',
  templateUrl: './footertab.component.html',
  styleUrls: ['./footertab.component.css']
})
export class FootertabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
