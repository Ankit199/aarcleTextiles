import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userinterface',
  templateUrl: './userinterface.component.html',
  styleUrls: ['./userinterface.component.css'],
  
})
export class UserinterfaceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
