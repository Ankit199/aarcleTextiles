import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultprofile',
  templateUrl: './defaultprofile.component.html',
  styleUrls: ['./defaultprofile.component.css']
})
export class DefaultprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
