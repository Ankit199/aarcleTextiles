import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-distributer',
  templateUrl: './distributer.component.html',
  styleUrls: ['./distributer.component.css']
})
export class DistributerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
