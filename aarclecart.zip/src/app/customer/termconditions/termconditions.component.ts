import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termconditions',
  templateUrl: './termconditions.component.html',
  styleUrls: ['./termconditions.component.css']
})
export class TermconditionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
