import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womensproduct',
  templateUrl: './womensproduct.component.html',
  styleUrls: ['./womensproduct.component.css']
})
export class WomensproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
