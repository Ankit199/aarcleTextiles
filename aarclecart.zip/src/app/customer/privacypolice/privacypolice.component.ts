import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privacypolice',
  templateUrl: './privacypolice.component.html',
  styleUrls: ['./privacypolice.component.css']
})
export class PrivacypoliceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
