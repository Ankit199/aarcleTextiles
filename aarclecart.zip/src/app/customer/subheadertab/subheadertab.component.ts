import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subheadertab',
  templateUrl: './subheadertab.component.html',
  styleUrls: ['./subheadertab.component.css']
})
export class SubheadertabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
