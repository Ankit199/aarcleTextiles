import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mensproduct',
  templateUrl: './mensproduct.component.html',
  styleUrls: ['./mensproduct.component.css']
})
export class MensproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
